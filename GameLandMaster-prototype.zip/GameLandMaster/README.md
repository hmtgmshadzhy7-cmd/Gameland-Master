# GameLand Master — prototype 0.1

An Android Studio starter project for a 6x6-dot (5x5-box) Dots-and-Boxes helper.

## Current prototype
- Kotlin solver core with edge indexing for a 6x6-dot board.
- Basic Android screen to mark occupied edges and request a suggested move.
- Immediately captures boxes when possible; otherwise applies a conservative heuristic.

## Not implemented yet
- Live screen capture / board recognition from GameLand.
- Floating overlay arrow above the game.
- Full game-theoretic search for chain/endgame positions.
- Automatic turn/color recognition.

## Build
Open this folder in Android Studio (JDK 17, Android SDK 35, Android Gradle Plugin 8.7.3), allow Gradle sync, then Build > Build Bundle(s) / APK(s) > Build APK(s).

This is a prototype source project, not a tested APK. The heuristic is not guaranteed to win.
