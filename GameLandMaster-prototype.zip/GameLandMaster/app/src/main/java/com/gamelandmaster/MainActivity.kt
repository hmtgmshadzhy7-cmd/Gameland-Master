package com.gamelandmaster

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import com.gamelandmaster.core.DotsAndBoxesSolver

class MainActivity : Activity() {
    private val edges = BooleanArray(DotsAndBoxesSolver.EDGE_COUNT)
    private lateinit var status: TextView
    private lateinit var board: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24) }
        status = TextView(this).apply { textSize = 18f; text = "صفحه آزمایشی ۶×۶ نقطه" }
        root.addView(status)
        val hint = TextView(this).apply { text = "برای آزمایش، خط‌های موجود را با دکمه‌ها علامت بزن؛ سپس پیشنهاد هوش بازی را بگیر."; textSize = 14f }
        root.addView(hint)
        board = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(board)
        val suggest = Button(this).apply { text = "پیشنهاد بهترین خط"; setOnClickListener { showMove() } }
        root.addView(suggest)
        val reset = Button(this).apply { text = "پاک کردن صفحه"; setOnClickListener { edges.fill(false); renderEdges() } }
        root.addView(reset)
        setContentView(root)
        renderEdges()
    }

    private fun renderEdges() {
        board.removeAllViews()
        for (i in edges.indices) {
            val b = Button(this).apply {
                text = "${if (i < DotsAndBoxesSolver.H_COUNT) "افقی" else "عمودی"} ${i + 1}: ${if (edges[i]) "پر" else "خالی"}"
                textSize = 11f
                setOnClickListener { edges[i] = !edges[i]; renderEdges() }
            }
            board.addView(b, LinearLayout.LayoutParams(-1, 42))
        }
        status.text = "خط‌های ثبت‌شده: ${edges.count { it }} از ${edges.size}"
    }

    private fun showMove() {
        val move = DotsAndBoxesSolver.recommend(edges)
        status.text = if (move == null) "بازی تمام شده است." else "خط پیشنهادی شماره ${move.edge + 1}: ${move.explanation}"
    }
}
