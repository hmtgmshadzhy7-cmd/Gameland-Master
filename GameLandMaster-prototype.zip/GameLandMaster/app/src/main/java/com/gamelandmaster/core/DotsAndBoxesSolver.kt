package com.gamelandmaster.core

/** 6x6 dots = 5x5 boxes. Edge ids: horizontal first, then vertical. */
object DotsAndBoxesSolver {
    const val DOTS = 6
    const val BOXES = 5
    const val H_COUNT = DOTS * (DOTS - 1)
    const val EDGE_COUNT = H_COUNT + (DOTS - 1) * DOTS

    data class Move(val edge: Int, val boxesCaptured: Int, val score: Double, val explanation: String)

    fun horizontal(r: Int, c: Int) = r * (DOTS - 1) + c
    fun vertical(r: Int, c: Int) = H_COUNT + r * DOTS + c

    private fun boxEdges(r: Int, c: Int) = intArrayOf(
        horizontal(r, c), horizontal(r + 1, c), vertical(r, c), vertical(r, c + 1)
    )

    private fun adjacentBoxes(edge: Int): List<Pair<Int, Int>> {
        val out = mutableListOf<Pair<Int, Int>>()
        if (edge < H_COUNT) {
            val r = edge / (DOTS - 1); val c = edge % (DOTS - 1)
            if (r > 0) out += (r - 1) to c
            if (r < BOXES) out += r to c
        } else {
            val v = edge - H_COUNT; val r = v / DOTS; val c = v % DOTS
            if (c > 0) out += r to (c - 1)
            if (c < BOXES) out += r to c
        }
        return out
    }

    fun recommend(occupied: BooleanArray): Move? {
        require(occupied.size == EDGE_COUNT) { "Expected $EDGE_COUNT edges for a 6x6-dot board" }
        val legal = occupied.indices.filter { !occupied[it] }
        if (legal.isEmpty()) return null
        data class Candidate(val edge: Int, val captures: Int, val danger: Int, val adjacentCounts: List<Int>)
        val candidates = legal.map { edge ->
            val counts = adjacentBoxes(edge).map { (r, c) -> boxEdges(r, c).count { occupied[it] } }
            val captures = counts.count { it == 3 }
            val danger = counts.count { it == 2 }
            Candidate(edge, captures, danger, counts)
        }
        // Take any immediately completable box. Otherwise prefer moves that do not create a 3-sided box.
        val best = candidates.maxWithOrNull(
            compareBy<Candidate> { it.captures }
                .thenBy { if (it.captures > 0) 0 else -it.danger }
                .thenBy { -it.adjacentCounts.count { n -> n == 1 } }
        ) ?: return null
        val why = when {
            best.captures > 0 -> "این خط ${best.captures} خانه را کامل می‌کند؛ امتیاز بگیر."
            best.danger == 0 -> "حرکت کم‌خطر: خانه مجاور را به وضعیت سه‌خطی نمی‌رساند."
            else -> "حرکت پیشنهادی موقت است؛ ممکن است به حریف فرصت تکمیل خانه بدهد."
        }
        val score = best.captures * 100.0 - best.danger * 12.0
        return Move(best.edge, best.captures, score, why)
    }
}
